import React from 'react';
import Title from "./Title";

const Footer = () => {
    return (
        <div>
            <Title title={'Footer'}/>
        </div>
    );
};

export default Footer;